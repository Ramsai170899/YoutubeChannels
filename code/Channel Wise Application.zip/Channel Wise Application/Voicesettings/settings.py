# Voice settings for each YouTube channel
channel_settings = {
    "Quantum Paradox": {
        "shortname": "QP",
        "voice": "en-US-AndrewMultilingualNeural",
        "rate": "+5%",
        "pitch": "+5Hz"
    },
    "The Cognitive Algorithm": {
        "shortname": "TCA",
        "voice": "en-GB-RyanNeural",
        "rate": "+0%",
        "pitch": "+0Hz"
    },
    "The Male Code": {
        "shortname": "TMC",
        "voice": "en-US-AndrewMultilingualNeural",
        "rate": "+5%",
        "pitch": "+0Hz"
    },
    "Money Mantra": {
        "shortname": "MM",
        "voice": "en-IN-PrabhatNeural",
        "rate": "+3%",
        "pitch": "+2Hz"
    },
    "Elevate": {
        "shortname": "ELV",
        "voice": "en-US-JennyNeural",
        "rate": "+8%",
        "pitch": "+4Hz"
    }
}