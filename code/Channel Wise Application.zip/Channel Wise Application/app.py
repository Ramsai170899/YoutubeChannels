from flask import Flask, render_template, request, jsonify, send_file
import edge_tts
import asyncio
import os
import re
from Voicesettings.settings import channel_settings
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/audio'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# Create upload folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# TTS function
async def text_to_speech(text, channel, filename="output"):
    settings = channel_settings[channel]
    shortname = settings["shortname"]
    voice = settings["voice"]
    rate = settings["rate"]
    pitch = settings["pitch"]

    text = re.sub(r"[*/#]", " ", text).replace("—", "; ")
    audio_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{shortname}_{filename}.mp3")
    tts = edge_tts.Communicate(text, voice=voice, rate=rate, pitch=pitch)
    await tts.save(audio_path)
    return audio_path

@app.route('/')
def index():
    channels = list(channel_settings.keys())
    return render_template('index.html', channels=channels)

@app.route('/generate', methods=['POST'])
def generate():
    try:
        channel = request.form['channel']
        filename = request.form['filename']
        script_text = request.form['script_text']
        
        # Validate inputs
        if not channel or not filename or not script_text:
            return jsonify({'error': 'All fields are required'}), 400
        
        if channel not in channel_settings:
            return jsonify({'error': 'Invalid channel selected'}), 400
        
        # Secure the filename
        filename = secure_filename(filename)
        
        # Run the TTS function
        audio_path = asyncio.run(text_to_speech(script_text, channel, filename))
        
        # Get the relative path for the frontend
        relative_path = audio_path.replace('static/', '')
        
        return jsonify({
            'success': True, 
            'audio_path': relative_path,
            'shortname': channel_settings[channel]['shortname'],
            'filename': filename
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download/<path:filename>')
def download_file(filename):
    return send_file(os.path.join('static', filename), as_attachment=True)

@app.route('/voices')
def get_voices():
    return jsonify(channel_settings)

if __name__ == '__main__':
    app.run(debug=True)