document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const form = document.getElementById('tts-form');
    const channelSelect = document.getElementById('channel');
    const filenameInput = document.getElementById('filename');
    const scriptTextarea = document.getElementById('script_text');
    const generateBtn = document.getElementById('generate-btn');
    const clearBtn = document.getElementById('clear-btn');
    const downloadBtn = document.getElementById('download-btn');
    const resultDiv = document.getElementById('result');
    const loadingDiv = document.getElementById('loading');
    const audioPlayer = document.getElementById('audio-player');
    const fileName = document.getElementById('file-name');
    const channelName = document.getElementById('channel-name');
    
    // Voice info elements
    const voiceName = document.getElementById('voice-name');
    const voiceRate = document.getElementById('voice-rate');
    const voicePitch = document.getElementById('voice-pitch');

    // Load voice settings
    let channelSettings = {};
    
    fetch('/voices')
        .then(response => response.json())
        .then(data => {
            channelSettings = data;
        })
        .catch(error => console.error('Error fetching voice settings:', error));

    // Update voice info when channel changes
    channelSelect.addEventListener('change', function() {
        const selectedChannel = this.value;
        
        if (selectedChannel && channelSettings[selectedChannel]) {
            const settings = channelSettings[selectedChannel];
            voiceName.textContent = settings.voice;
            voiceRate.textContent = settings.rate;
            voicePitch.textContent = settings.pitch;
        } else {
            voiceName.textContent = 'Select a channel';
            voiceRate.textContent = '-';
            voicePitch.textContent = '-';
        }
    });

    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const channel = channelSelect.value;
        const filename = filenameInput.value;
        const scriptText = scriptTextarea.value;
        
        // Validate inputs
        if (!channel || !filename || !scriptText) {
            showAlert('Please fill all required fields', 'error');
            return;
        }
        
        // Show loading state
        resultDiv.classList.add('hidden');
        loadingDiv.classList.remove('hidden');
        generateBtn.disabled = true;
        
        // Prepare form data
        const formData = new FormData();
        formData.append('channel', channel);
        formData.append('filename', filename);
        formData.append('script_text', scriptText);
        
        // Send request to server
        fetch('/generate', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update audio player
                audioPlayer.src = `/static/${data.audio_path}`;
                
                // Update info
                fileName.textContent = `Filename: ${data.shortname}_${data.filename}.mp3`;
                channelName.textContent = `Channel: ${channel}`;
                
                // Set download link
                downloadBtn.onclick = function() {
                    window.location.href = `/download/${data.audio_path}`;
                };
                
                // Show result
                resultDiv.classList.remove('hidden');
                
                // Animate scroll to result
                resultDiv.scrollIntoView({ behavior: 'smooth' });
            } else {
                showAlert(data.error || 'An error occurred', 'error');
            }
        })
        .catch(error => {
            showAlert('Failed to generate audio: ' + error, 'error');
        })
        .finally(() => {
            // Hide loading state
            loadingDiv.classList.add('hidden');
            generateBtn.disabled = false;
        });
    });

    // Clear form
    clearBtn.addEventListener('click', function() {
        filenameInput.value = '';
        scriptTextarea.value = '';
        resultDiv.classList.add('hidden');
    });

    // Helper function to show alerts
    function showAlert(message, type) {
        // Create alert element
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type}`;
        alertDiv.innerHTML = `
            <div class="alert-content">
                <i class="fas fa-${type === 'error' ? 'exclamation-circle' : 'check-circle'}"></i>
                <span>${message}</span>
            </div>
            <button class="alert-close"><i class="fas fa-times"></i></button>
        `;
        
        // Style the alert
        alertDiv.style.position = 'fixed';
        alertDiv.style.top = '20px';
        alertDiv.style.right = '20px';
        alertDiv.style.padding = '12px 20px';
        alertDiv.style.borderRadius = '5px';
        alertDiv.style.display = 'flex';
        alertDiv.style.justifyContent = 'space-between';
        alertDiv.style.alignItems = 'center';
        alertDiv.style.backgroundColor = type === 'error' ? '#ff4757' : '#28a745';
        alertDiv.style.color = 'white';
        alertDiv.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
        alertDiv.style.zIndex = '1000';
        alertDiv.style.minWidth = '300px';
        alertDiv.style.maxWidth = '450px';
        alertDiv.style.animation = 'slideIn 0.3s forwards';
        
        // Create a style for the animation
        const style = document.createElement('style');
        style.innerHTML = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            .alert-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .alert-close {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                padding: 0;
                display: flex;
                align-items: center;
            }
        `;
        document.head.appendChild(style);
        
        // Add to document
        document.body.appendChild(alertDiv);
        
        // Close button functionality
        const closeBtn = alertDiv.querySelector('.alert-close');
        closeBtn.addEventListener('click', function() {
            alertDiv.style.animation = 'slideOut 0.3s forwards';
            setTimeout(() => {
                alertDiv.remove();
            }, 300);
        });
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(alertDiv)) {
                alertDiv.style.animation = 'slideOut 0.3s forwards';
                setTimeout(() => {
                    if (document.body.contains(alertDiv)) {
                        alertDiv.remove();
                    }
                }, 300);
            }
        }, 5000);
    }
});