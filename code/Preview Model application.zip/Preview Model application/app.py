from flask import Flask, render_template, request, jsonify, send_from_directory
import edge_tts
import asyncio
import pandas as pd
import re
import os
import uuid
import shutil
import pycountry

app = Flask(__name__)
output_folder = "output"
temp_folder = "temp_output"
os.makedirs(output_folder, exist_ok=True)
os.makedirs(temp_folder, exist_ok=True)

# -------------------------


async def get_voices_df():
    voices = await edge_tts.list_voices()
    df = pd.DataFrame(voices)

    df['FriendlyName'] = df['FriendlyName'].apply(
        lambda x: re.sub(r'Microsoft|Online|Natural', '', x))
    df['FriendlyName'] = df['FriendlyName'].apply(
        lambda x: x.replace('(', '').replace(')', ''))
    df['FriendlyName'] = df['FriendlyName'].apply(
        lambda x: re.sub(r'[-_]', ' ', x))
    df['FriendlyName'] = df['FriendlyName'].apply(
        lambda x: re.sub(r'\s+', ' ', x).strip())

    def get_language_name(locale):
        language_code = locale.split('-')[0]
        try:
            language = pycountry.languages.get(alpha_2=language_code)
            return language.name if language else 'Unknown'
        except AttributeError:
            return 'Unknown'

    df['Language'] = df['Locale'].apply(get_language_name)
    return df

voices_df = asyncio.run(get_voices_df())
languages = voices_df['Language'].unique().tolist()


def get_available_voices(selected_language, gender):
    voices_filtered = voices_df[
        (voices_df['Gender'] == gender) &
        (voices_df['Language'] == selected_language)
    ][['ShortName', 'FriendlyName']]
    voices_list = voices_filtered.apply(tuple, axis=1).tolist()
    return voices_list

# ------------------------------


async def text_to_speech_temp(text, voice="en-US-GuyNeural", rate="+0%", pitch="+0Hz"):
    text = re.sub(r"[*/#₹-]", " ", text).replace("—", ". ")
    temp_filename = f"{uuid.uuid4().hex}.mp3"
    temp_path = os.path.join(temp_folder, temp_filename)
    tts = edge_tts.Communicate(text, voice=voice, rate=rate, pitch=pitch)
    await tts.save(temp_path)
    return temp_filename

# ------------------------------


def clear_temp_folder():
    for f in os.listdir(temp_folder):
        file_path = os.path.join(temp_folder, f)
        if os.path.isfile(file_path):
            os.remove(file_path)

# ------------------------------


@app.route("/", methods=["GET", "POST"])
def index():
    genders = ["Male", "Female"]
    selected_gender = "Male"
    selected_language = "English"
    selected_voice_name = None
    voices = get_available_voices(selected_language, selected_gender)
    temp_audio_file = None
    saved_audio_file = None
    filename_input = ""
    text_input = ""
    rate_value = "10"
    pitch_value = "-10"

    if request.method == "POST":
        text_input = request.form.get("text")
        filename_input = request.form.get("filename")
        selected_gender = request.form.get("gender")
        selected_language = request.form.get("language")
        selected_voice_name = request.form.get("voice")  # Capture correctly
        rate_value = request.form.get("rate")
        pitch_value = request.form.get("pitch")
        action = request.form.get("action")
        temp_filename_form = request.form.get("temp_filename")

        voices = get_available_voices(selected_language, selected_gender)
        selected_voice_tuple = next(
            (v for v in voices if v[1] == selected_voice_name), None)

        if text_input and filename_input and selected_voice_tuple:
            selected_voice_shortname = selected_voice_tuple[0]
            rate_str = f"{'+' if int(rate_value) >= 0 else ''}{int(rate_value)}%"
            pitch_str = f"{'+' if int(pitch_value) >= 0 else ''}{int(pitch_value)}Hz"

            # Preview Action
            if action == "preview":
                # Generate fresh temp file
                temp_filename = asyncio.run(text_to_speech_temp(
                    text_input, selected_voice_shortname, rate_str, pitch_str))
                temp_audio_file = temp_filename

            # Save Action
            elif action == "save":
                temp_filename = temp_filename_form  # Get correct temp filename
                if temp_filename:
                    clean_shortname = selected_voice_shortname.replace(
                        '-', '_')
                    final_filename = f"{filename_input}-{clean_shortname}.mp3"
                    temp_path = os.path.join(temp_folder, temp_filename)
                    final_path = os.path.join(output_folder, final_filename)

                    # Ensure temp file exists
                    if os.path.exists(temp_path):
                        shutil.move(temp_path, final_path)
                        saved_audio_file = final_filename

    return render_template("index.html",
                           genders=genders,
                           languages=languages,
                           voices=voices,
                           selected_gender=selected_gender,
                           selected_language=selected_language,
                           selected_voice_name=selected_voice_name,
                           temp_audio_file=temp_audio_file,
                           saved_audio_file=saved_audio_file,
                           filename_input=filename_input,
                           text_input=text_input,
                           rate_value=rate_value,
                           pitch_value=pitch_value)


# ------------------------------


@app.route("/get_voices/<gender>/<language>")
def get_voices_api(gender, language):
    voices = get_available_voices(language, gender)
    voice_names = [v[1] for v in voices]
    return jsonify(voice_names)

# ------------------------------


@app.route("/temp_audio/<filename>")
def temp_audio(filename):
    return send_from_directory(temp_folder, filename)


@app.route("/download/<filename>")
def download(filename):
    return send_from_directory(output_folder, filename, as_attachment=True)


if __name__ == '__main__':
    app.run(host='192.168.1.7', debug=True)
